import java.util.ArrayList;
import java.util.LinkedList;

public class UsingArrayList {
    public static void main(String[] args) {
        ArrayList<Student> myArrayList = new ArrayList<Student>();
        LinkedList<Student> myLinkedList = new LinkedList<Student>();
    }
}
