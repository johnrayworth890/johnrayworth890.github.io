public class Node {
    private Object data = null;
    private Node pointer = null;

    public Node(){

    }

    public Node(Object data){
        this.data = data;
    }

    public Object getData(){
        return data;
    }

    public Node getNext() {
        return pointer;
    }

    public void setNext(Node next){
        this.pointer = next;
    }
}
