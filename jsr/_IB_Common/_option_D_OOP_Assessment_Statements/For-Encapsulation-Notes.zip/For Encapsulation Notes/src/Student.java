import java.util.ArrayList;

public class Student {
    private String studentName = "not set yet";
    private int grade = -999;
    private boolean isIBDiploma = false;
    ArrayList<BookLoan> bookLoans = new ArrayList<BookLoan>();
    //so an example of aggregation; Student objects have BookLoans

    //Constructors
    public Student(){

    }

    public Student(String name, int grade){
        studentName = name;
        this.grade = grade;
    }

    public Student(String name, int grade, boolean isIBDiploma){
        studentName = name;
        this.grade = grade;
        this.isIBDiploma = isIBDiploma;
    }

    //THE FOLLOWING ARE ALL EXAMPLES OF THE "GROUPING/ASSOCIATION"
    //PART OF ENCAPSULATION - ALL OF THE METHODS THAT WORK WITH
    //THE ABOVE ATTRIBUTES ARE GROUPED HERE IN THIS CLASS
    //PARTICULARLY NOTE THE addLoan() METHOD BELOW...

    //"Gets", i.e. Accessor Methods
    public String getStudentName() {
        return studentName;
    }

    public int getGrade() {
        return grade;
    }

    public ArrayList<BookLoan> getBookLoans(){
        return bookLoans;
    }

    public boolean isIBDiploma() {
        return isIBDiploma;
    }

    //"Sets"
    public void setGrade(int grade){
        this.grade = grade;
    }

    public void setIBDiploma(boolean isIBDiploma){
        this.isIBDiploma = isIBDiploma;
    }

    //Other "Modifier" Methods

    //... SO THIS IS THE MOST IMPORTANT METHOD TO BE "GROUPED/ASSOCIATED"
    //WITH THE DATA ATTRIBUTES ABOVE. ONLY THIS METHOD CAN DETERMINE
    //WHETHER OR NOT ANOTHER BOOK CAN BE LOANED. AND THE IMPLEMENTATION
    //OF THAT IS ALL HIDDEN TO OTHER CLASSES. THE ONLY THING THAT THEY
    //CAN SEE IS THE PUBLIC HEADER BELOW.

    public void addLoan(BookLoan newLoan){
        if(bookLoans.size() > 0 && (this.grade < 11 || !isIBDiploma)){
            System.out.println("Sorry you cannot take out another book");
            if(this.grade < 11){
                System.out.println("because of your grade level.\n");
            }
            else{
                System.out.println("even though you are grade 11 or 12, because" +
                        " you are not a full IB diploma student.\n");
            }
        }
        else{
            bookLoans.add(newLoan);
        }

    }
}
