public class BookLoan {
    private int bookID;
    private String bookTitle;
    static int numBooksLoaned = 0;

    //Constructors
    public BookLoan(){

    }

    public BookLoan(int bookID, String bookTitle){
        this.bookID = bookID;
        this.bookTitle = bookTitle;
        numBooksLoaned = numBooksLoaned ++;
    }

    //"Gets", i.e. Accessor Methods
    public int getBookID(){
        return this.bookID;
    }

    public String getBookTitle(){
        return this.bookTitle;
    }

    //"Sets"
    public void setBookID(int id){
        this.bookID = id;
    }

    public void setBookTitle(String title){
        this.bookTitle = title;
    }
}
