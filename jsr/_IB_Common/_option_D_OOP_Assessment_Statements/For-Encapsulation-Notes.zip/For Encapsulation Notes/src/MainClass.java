public class MainClass {
    public static void main(String[] args) {

        Student[] borrowers = new Student[2000];
        //Note using an array instead of an ArrayList, so lots of elements wasted
        //here, since there are only three students created, but 2000 elements made.

        Student zangChi = new Student("Zang Chi", 11, true);
        zangChi.addLoan(new BookLoan(345, "The Animals"));
        zangChi.addLoan(new BookLoan(678, "War and Peace"));
        //OK, since a book already on loan, but in grade 11, and is IBDiploma student.
        borrowers[0] = zangChi;

        Student SooYongKim = new Student("Soo Yong Kim", 10);
        SooYongKim.addLoan(new BookLoan(1234, "The Odyssey"));
        SooYongKim.addLoan(new BookLoan(56645, "Don Quixote"));
        //Not OK, grade 10 and already a book on loan.

        //------->>>> THIS IS AN EXAMPLE OF THE "PROTECTION" PART OF ENCAPSULATION
        //DOING ITS JOB; THIS MainClass PROGRAM CANNOT DO ANYTHING TO TAKE OUT ANY
        //MORE BOOKS FOR THIS STUDENT; NOTHING **HERE** CAN BE DONE TO CHANGE THAT.
        //IT IS ALL CONTROLLED BACK IN THE HIDDEN PART OF addLoan().
        borrowers[1] = SooYongKim;

        Student JoeNguyen = new Student("Joe Nguyen", 12, false);
        JoeNguyen.addLoan(new BookLoan(23423, "The Ocean"));
        JoeNguyen.addLoan(new BookLoan(75675, "Love in the Time of Cholera"));
        //Not OK, grade 11 and already a book on loan, and not IBDiploma student.
        borrowers[2] = JoeNguyen;


        borrowers[1].addLoan(new BookLoan(8778, "Wuthering Heights"));
        //Not OK, grade 10 and still a book on loan.
        borrowers[0].addLoan(new BookLoan(868, "The Spooks"));
        //OK, since a book already on loan, but in grade 11, and is IBDiploma student.




        System.out.println("----------------");
        System.out.println(borrowers[0].getStudentName() + ":");
        for(int i = 0; i < borrowers[0].getBookLoans().size(); i++){
            System.out.println(borrowers[0].getBookLoans().get(i).getBookTitle());
        }

        System.out.println("----------------");
        System.out.println(borrowers[1].getStudentName() + ":");
        for(int i = 0; i < borrowers[1].getBookLoans().size(); i++){
            //Do note that the size of the arraylist is 1, but this will still work.
            System.out.println(borrowers[1].getBookLoans().get(i).getBookTitle());
        }

        System.out.println("----------------");
        System.out.println(borrowers[2].getStudentName() + ":");
        for(int i = 0; i < borrowers[2].getBookLoans().size(); i++){
            System.out.println(borrowers[2].getBookLoans().get(i).getBookTitle());
        }
    }
}
