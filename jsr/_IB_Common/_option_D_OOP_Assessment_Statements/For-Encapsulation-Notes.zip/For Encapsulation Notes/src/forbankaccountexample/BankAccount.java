package forbankaccountexample;

public class BankAccount {

    private double checkingAccountBalance = -999;


    public String adjustCkBalance(String pw, double amt) {
        String returnString = "not set yet";
        if (pw.equals("!asdf@#$sdfLJk")) {
            if (amt < 0 && amt < checkingAccountBalance) {
                returnString = "Sorry, withdraw amount is less than current balance.";
            } else {
                checkingAccountBalance += amt;
            }
        }
        else{
                returnString = "Sorry, wrong password.";
        }return "Your new balance is " + checkingAccountBalance;
    }
}

