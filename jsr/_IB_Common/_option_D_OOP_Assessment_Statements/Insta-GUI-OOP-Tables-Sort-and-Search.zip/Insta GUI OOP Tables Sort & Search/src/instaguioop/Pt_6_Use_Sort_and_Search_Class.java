
package instaguioop;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author John Rayworth 
 * International School of Prague
 */
public class Pt_6_Use_Sort_and_Search_Class {

    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    static Student[] studentsArray = new Student[10];

    public static void main(String[] args) throws IOException {
        makeHardCodedArray();
        searchingPart();
    }

    private static void makeHardCodedArray() throws IOException{
        studentsArray[0] = new Student("Sally", 11);
        studentsArray[1] = new Student("Bob", 12);
        studentsArray[2] = new Student("Frank", 10);
        studentsArray[3] = new Student("Mary", 9);
        studentsArray[4] = new Student("Jane", 11);
        studentsArray[5] = new Student("John", 11);
        studentsArray[6] = new Student("Sarah", 10);
        studentsArray[7] = new Student("Anne", 12);
        studentsArray[8] = new Student("Chisanga", 10);
        studentsArray[9] = new Student("Tafadswa", 11);
        
        //Or get the user to input the names and grades:
        /*System.out.println("Who would you like to search for?");
        String studentToSearchFor = br.readLine();
        int result = sequentialSearch(studentToSearchFor, studentsArray);
        if(result != -1){
            System.out.println(studentToSearchFor + " was found");
            System.out.println("Their grade is: " + studentsArray[result].getGrade());
        }else{
            System.out.println("That student is not in the database.");
        }*/
    }

    private static void searchingPart() throws IOException {
        System.out.println("Who would you like to search for?");
        String studentToSearchFor = br.readLine();

        StudentSortAndSearch s = new StudentSortAndSearch();
        
        s.smartestBubbleSortByStudent(studentsArray);
        int result = s.binarySearchOfStudent(studentsArray, studentToSearchFor);
        if (result != -1) {
            System.out.println(studentToSearchFor + " was found");
            System.out.println("Their grade is: " + studentsArray[result].getGrade());
        } else {
            System.out.println("That student is not in the database.");
        }
    }

}