
package instaguioop;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author John Rayworth
 * International School of Prague
 */
public class Pt_4_Search_of_Objects_B {
    
    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    static Student [] userInputArray = new Student[5];
    
    public static void main(String[] args) throws IOException {
        makeUserInputArray();
        System.out.println("---------------");
        searchingPart();
    }
    
    private static void makeUserInputArray() throws IOException{
        
        for(int i = 0; i < userInputArray.length; i++){
            userInputArray[i] = new Student();
        }
        for(int i = 0; i < userInputArray.length; i++){
            System.out.println("What is the name of the next student?");
            String name = br.readLine();
            System.out.println("What grade is the student in?");
            int grade = Integer.parseInt(br.readLine());
            userInputArray[i] = new Student(name, grade);
        }
    }
    
    private static void searchingPart() throws IOException{
        System.out.println("Who would you like to search for?");
        String studentToSearchFor = br.readLine();
        int result = sequentialSearch(studentToSearchFor, userInputArray);
        if(result != -1){
            System.out.println(studentToSearchFor + " was found");
            System.out.println("Their grade is: " + userInputArray[result].getGrade());
        }else{
            System.out.println("That student is not in the database.");
        }
    }
    
    
    private static int sequentialSearch(String studentToSearchFor, Student [] studentsArray){
        for(int i = 0; i < studentsArray.length; i++){
            if(studentsArray[i].getName().equals(studentToSearchFor)){
                return i;
            }
        }
        return -1;
    }
    

    
    
}
