/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package instaguioop;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author johnrayworth
 */
public class Pt_5_Sort_and_Search1 {
    
    static Student [] arr = new Student[5];
    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    
    public static void main(String[] args) throws IOException {
        for(int i = 0; i < arr.length; i++){
           arr[i] = new Student(); 
        }
        hardCodeArray();
        searchArray();    
    }
    
    public static void hardCodeArray(){
        arr[0] = new Student("Charlie", 10);
        arr[1] = new Student("Suzette", 11);
        arr[2] = new Student("Sahah", 10);
        arr[3] = new Student("Sally", 12);
        arr[4] = new Student("Bob", 9);
    }
    
    public static void searchArray() throws IOException{
        smartestBubbleSort(arr);
        //for(int i = 0; i < arr.length; i++){
            //System.out.println(arr[i].getName());
        //}
        System.out.println("Which student's grade do you wish to look up?");
        String name = br.readLine();
        int result = binarySearch(arr, name);
        if(result == -1){
            System.out.println(name + " was not found. We're sorry.");
        }else{
            System.out.println(name + " was found. They are in grade " + arr[result].getGrade());
        }
    }
    
     public static int binarySearch(Student [] studentArray, String key) {
        //an int called low initalized to 0;
         int low = 0;
        //an int called high, initialized to one minus the length of the array
         int high = studentArray.length - 1;
        // continue looping whle the low is less than the high
         while(low <= high){
             // an int mid which is the high plus low / 2
             int mid = (low + high) / 2;
            // if what we are lookin for is equla to the mid,
             if(studentArray[mid].getName().equals(key)){
                 // we return the mid.
                 return mid;
             }
             // else if the mid is less than what we aer looking for,
             else if(studentArray[mid].getName().compareTo(key) < 0){
                 //the low becomes the mid plus 1
                 low = mid + 1;
             }
             // else (if the mid is greater than what we are looking for)
             else{
                 // it's the high which switches, to the mid - 1
                 high = mid -1;
             }
         }
        // return -1 indicating the mid was never the thing looked for
        return -1;
    }
    
    
    public static void smartestBubbleSort(Student [] s){
        //n is the length of the array
        int n = s.length;
       // a boolean sorted is false
        boolean sorted = false;
        //while not sorted
        while(!sorted){
           // n goes down by one
           n--; 
           //sorted is assumed to be true
           sorted = true;
             //loop through the array
           for(int i = 0; i < n ; i++){
              //if the student name at the ith is greater than the name at i+1 (use compareTo)
              if(s[i].getName().compareTo(s[i+1].getName()) > 0){
               // make a temp Student
                  Student temp = s[i];
               // the Student i is Student i+1
                  s[i] = s[i+1];
                // Stueent i+1 is assigned the temp
                  s[i+1] = temp;
            // sorted becomes false
                  sorted = false;
              }
           }
         }     
   
    }
    
}
