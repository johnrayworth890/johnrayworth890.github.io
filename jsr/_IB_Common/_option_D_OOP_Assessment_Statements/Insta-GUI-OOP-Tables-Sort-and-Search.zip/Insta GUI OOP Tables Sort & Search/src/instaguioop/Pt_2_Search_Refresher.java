
package instaguioop;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author John Rayworth
 * International School of Prague
 */
public class Pt_2_Search_Refresher {
    
    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    
    public static void main(String[] args) throws IOException {
        String [] arr = {"Bob", "Sally", "Charlie", "Betty"};
        System.out.println("Who would you like to check to see if they are in the array?");
        String studentToSearch = br.readLine();
        int result = sequentialSearch(arr, studentToSearch);
        if(result != -1){
            System.out.println("Yes, " + studentToSearch + " is at index " + result);
        }
    }
    
    public static int sequentialSearch(String [] arr, String key){
        for(int i = 0; i < arr.length; i++){
            if(arr[i].equals(key)){
                return i;
            }
        }
        return -1;
    }
    
}
