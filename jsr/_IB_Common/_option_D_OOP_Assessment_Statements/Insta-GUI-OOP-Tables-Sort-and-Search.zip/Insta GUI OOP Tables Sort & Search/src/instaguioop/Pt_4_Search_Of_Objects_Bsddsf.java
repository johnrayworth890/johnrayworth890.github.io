/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package instaguioop;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author johnrayworth
 */
public class Pt_4_Search_Of_Objects_Bsddsf {

    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    static Student[] studentArray = new Student[5];

    public static void main(String[] args) throws IOException {
        addToDatabase();
        searchDatabase();
    }

    public static void addToDatabase() throws IOException {
        for (int i = 0; i < studentArray.length; i++) {
            studentArray[i] = new Student();
        }
        System.out.println("What is the name of the first student?");
        studentArray[0].setName(br.readLine());
        System.out.println("What grade is " + studentArray[0].getName() + "'s in?");
        studentArray[0].setGrade(Integer.parseInt(br.readLine()));
        System.out.println("-------------");

        for (int i = 1; i < studentArray.length - 1; i++) {
            System.out.println("What is the name of the next student?");
            studentArray[i].setName(br.readLine());
            System.out.println("What grade is " + studentArray[i].getName() + "'s in?");
            studentArray[i].setGrade(Integer.parseInt(br.readLine()));
            System.out.println("-------------");
        }
        System.out.println("What is the name of the last student?");
        studentArray[studentArray.length - 1].setName(br.readLine());
        System.out.println("What grade is " + studentArray[studentArray.length - 1].getName() + "'s in?");
        studentArray[studentArray.length - 1].setGrade(Integer.parseInt(br.readLine()));
        System.out.println("-------------");

    }

    public static void searchDatabase() throws IOException {
        System.out.println("What student's grade would you like to search for?");
        String student = br.readLine();
        int result = sequentialSearch(studentArray, student);
        if(result == -1){
            System.out.println("Sorry but the student was not found.");
        }
        else{
            
        }
    }
    
    public static int sequentialSearch(Student [] arr, String key){
        for(int i = 0; i < arr.length; i++){
            if(arr[i].getName().equals(key)){
                return i;
            }
        }
        return -1;
    }
    
}
