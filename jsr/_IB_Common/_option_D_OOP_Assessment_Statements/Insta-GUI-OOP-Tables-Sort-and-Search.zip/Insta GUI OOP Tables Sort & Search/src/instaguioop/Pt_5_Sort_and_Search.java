
package instaguioop;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author John Rayworth 
 * International School of Prague
 */
public class Pt_5_Sort_and_Search {

    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    static Student[] studentsArray = new Student[10];

    public static void main(String[] args) throws IOException {
        makeHardCodedArray();
        searchingPart();
    }

    private static void makeHardCodedArray() throws IOException{
        studentsArray[0] = new Student("Sally", 11);
        studentsArray[1] = new Student("Bob", 12);
        studentsArray[2] = new Student("Frank", 10);
        studentsArray[3] = new Student("Mary", 9);
        studentsArray[4] = new Student("Jane", 11);
        studentsArray[5] = new Student("John", 11);
        studentsArray[6] = new Student("Sarah", 10);
        studentsArray[7] = new Student("Anne", 12);
        studentsArray[8] = new Student("Chisanga", 10);
        studentsArray[9] = new Student("Tafadswa", 11);
        
        //Or get the user to input the names and grades:
        /*System.out.println("Who would you like to search for?");
        String studentToSearchFor = br.readLine();
        int result = sequentialSearch(studentToSearchFor, studentsArray);
        if(result != -1){
            System.out.println(studentToSearchFor + " was found");
            System.out.println("Their grade is: " + studentsArray[result].getGrade());
        }else{
            System.out.println("That student is not in the database.");
        }*/
    }

    private static void searchingPart() throws IOException {
        System.out.println("Who would you like to search for?");
        String studentToSearchFor = br.readLine();

        smartestBubbleSort(studentsArray);
        int result = binarySearch(studentsArray, studentToSearchFor);
        if (result != -1) {
            System.out.println(studentToSearchFor + " was found");
            System.out.println("Their grade is: " + studentsArray[result].getGrade());
        } else {
            System.out.println("That student is not in the database.");
        }
    }

    public static void smartestBubbleSort(Student [] studentArray) {
        int n = studentArray.length;//n is the length of the array
        boolean sorted = false;// a boolean sorted is false
        while (!sorted) {//while not sorted
            n--; // n goes down by one
            sorted = true; //sorted is assumed to be true
            for (int i = 0; i < n; i++) { //loop through the array
                if (studentArray[i].getName().compareTo(studentArray[i + 1].getName()) > 0) {
                    //if the student name at the ith is greater than the name at i+1 (use compareTo)
                    Student temp = studentArray[i]; // make a temp Student
                    studentArray[i] = studentArray[i + 1]; // the Student i is Student i+1
                    studentArray[i + 1] = temp; // Stueent i+1 is assigned the temp
                    sorted = false; // sorted becomes false
                }
            }
        }
    }

    public static int binarySearch(Student [] studentArray, String key) {
        //an int called low initalized to 0;
        int low = 0;
        //an int called high, initialized to one minus the length of the array
        int high = studentArray.length - 1;
        // continue looping whle the low is less than the high
        while (low <= high) {
            // an int mid which is the high plus low / 2
            int mid = (low + high) / 2;
            // if what we are lookin for is equla to the mid,
            if (studentArray[mid].getName().equals(key)) {
                // we return the mid.
                return mid;
            } 
            // else if the mid is less than what we aer looking for,
            else if (studentArray[mid].getName().compareTo(key) < 0) {
                //the low becomes the mid plus 1
                low = mid + 1;
            } 
            // else (if the mid is greater than what we are looking for)
            else {
                // it's the high which switches, to the mid - 1
                high = mid - 1;
            }
        }
        // return -1 indicating the mid was never the thing looked for
        return -1;
        
    }
}