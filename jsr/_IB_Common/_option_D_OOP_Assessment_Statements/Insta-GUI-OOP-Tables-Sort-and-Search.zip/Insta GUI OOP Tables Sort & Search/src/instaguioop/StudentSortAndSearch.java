package instaguioop;

/**
 *
 * @author John Rayworth
 */
public class StudentSortAndSearch {

    public StudentSortAndSearch() {
    }

    public void smartestBubbleSortByStudent(Student[] studentArray) {
        int n = studentArray.length;
        boolean sorted = false;
        while (!sorted) {
            n--;
            sorted = true;
            for (int i = 0; i < n; i++) {
                if (studentArray[i].getName().compareTo(studentArray[i + 1].getName()) > 0) {
                    Student temp = studentArray[i];
                    studentArray[i] = studentArray[i + 1];
                    studentArray[i + 1] = temp;
                    sorted = false;
                }
            }
        }
    }

    public void smartestBubbleSortByGrade(Student[] studentArray) {
        int n = studentArray.length;
        boolean sorted = false;
        while (!sorted) {
            n--;
            sorted = true;
            for (int i = 0; i < n; i++) {
                if (studentArray[i].getGrade() >  studentArray[i + 1].getGrade()) {
                    Student temp = studentArray[i];
                    studentArray[i] = studentArray[i + 1];
                    studentArray[i + 1] = temp;
                    sorted = false;
                }
            }
        }
    }
    
    public int binarySearchOfStudent(Student[] studentArray, String key) {
        int low = 0;
        int high = studentArray.length - 1;
        while (low <= high) {
            int mid = (low + high) / 2;
            if (studentArray[mid].getName().equals(key)) {
                return mid;
            } else if (studentArray[mid].getName().compareTo(key) < 0) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }
        return -1;
    }
    
    public Student [] searchOfAllOfOneGrade(Student [] studentArray, int key){
        Student [] resultArray = new Student[10];
        for(int i = 0; i < resultArray.length; i++){
            resultArray[i] = new Student();
        }
        int counter = 0;
        for(int i = 0; i < studentArray.length; i++){
            if(studentArray[i].getGrade() == key){
                resultArray[counter] = studentArray[i];
                counter++;
            }
        }
        
        return resultArray;
    }

    
}
