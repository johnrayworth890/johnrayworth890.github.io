
package instaguioop;

/**
 *
 * @author John Rayworth 
 * International School of Prague
 */
public class Student {
    
    private String name = "not set yet";
    private int grade = -999;
    
    public Student(){
        
    }
    
    public Student(String name, int grade){
        this.name = name;
        this.grade = grade;
    }
    
    public String getName(){
        return name;
    }
    
    public int getGrade(){
        return grade;
    }
    
    public void setName(String name){
        this.name = name;
    }
    
    public void setGrade(int grade){
        this.grade = grade;
    }
    
}
