
package instaguioop;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author John Rayworth
 * International School of Prague
 */
public class Pt_3_Search_of_Objects_A {
    
    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    static Student [] studentsArray = new Student[10];
    
    public static void main(String[] args) throws IOException {
        makeHardCodedArray();
        searchingPart();
    }
    
     private static void makeHardCodedArray(){     
        studentsArray[0] = new Student("Sally", 11);
        studentsArray[1] = new Student("Bob", 12);
        studentsArray[2] = new Student("Frank", 10);
        studentsArray[3] = new Student("Mary", 9);
        studentsArray[4] = new Student("Jane", 11);
        studentsArray[5] = new Student("John", 11);
        studentsArray[6] = new Student("Sarah", 10);
        studentsArray[7] = new Student("Anne", 12);
        studentsArray[8] = new Student("Chisanga", 10);
        studentsArray[9] = new Student("Tafadswa", 11);
    }
     
    private static void searchingPart() throws IOException{
        System.out.println("Who would you like to search for?");
        String studentToSearchFor = br.readLine();
        int result = sequentialSearch(studentToSearchFor, studentsArray);
        if(result != -1){
            System.out.println(studentToSearchFor + " was found");
            System.out.println("Their grade is: " + studentsArray[result].getGrade());
        }else{
            System.out.println("That student is not in the database.");
        }
    }
    
    
    private static int sequentialSearch(String studentToSearchFor, Student [] studentsArray){
        for(int i = 0; i < studentsArray.length; i++){
            if(studentsArray[i].getName().equals(studentToSearchFor)){
                return i;
            }
        }
        return -1;
    }
    
    
    
}
