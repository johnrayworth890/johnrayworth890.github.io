package may2014_genus_species;

public class Genus {
    private String genusName;

    public Genus(){

    }

    public Genus(String genusName){
        this.genusName = genusName;
    }

    public String getGenusName() {
        return genusName;
    }
}
