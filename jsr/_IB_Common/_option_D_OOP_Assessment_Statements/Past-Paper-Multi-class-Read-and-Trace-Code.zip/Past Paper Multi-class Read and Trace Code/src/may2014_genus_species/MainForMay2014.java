package may2014_genus_species;

import java.util.LinkedList;

public class MainForMay2014 {
    public static void main(String[] args) {
        Species human = new Species ( "homo", "sapiens" );
        System.out.println( human.toString() );
    }

    //Post conditions: output the number of specimens of the given species in the zoo.
    public void countSpecimens( Specimen[] animals, Species s ){
        //To Do
    }

    //Post conditions: will generate a list of the different species in the zoo.
    public void listSpecies( Specimen[] animals ){
        //To Do
    }

    public LinkedList makeList(Specimen[] animals )
    {
        // insert your code here
        return new LinkedList<Species>();//for now just to take away the return red squiggly
    }
}
