package may2016_hotels;

public class Room {
    private int roomNumber;
    private int beds;
    private double price;
    private boolean empty;

    public Room(){

    }
}
