package november2015_healthclinic;

public class Patient
{
    private int id;
    private String name;
    private int priority;
    private String doctor;

    public Patient(){

    }

    public Patient(int i, String n, int p)
    {
        id = i;
        name = n;
        priority = p;
        doctor = null;
    }

    public void setId(int i) { id = i; }
    public void setName(String n) { name = n; }
    public void setPriority(int p) { priority = p; }
    public void setDoctor(String d) { doctor = d; }

    public int getId() { return id; }
    public String getName() { return name; }
    public int getPriority() { return priority; }
    public String getDoctor() { return doctor; }

    public String toString() { return id+" "+name+" "+priority+" "+doctor; }
}
