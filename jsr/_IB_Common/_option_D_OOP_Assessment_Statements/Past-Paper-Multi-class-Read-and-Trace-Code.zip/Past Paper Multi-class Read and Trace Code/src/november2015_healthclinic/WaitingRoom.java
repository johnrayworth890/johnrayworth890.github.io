package november2015_healthclinic;

public class WaitingRoom
{
    private Patient[] patients = new Patient[10];
    // uses default constructor

    public void add(Patient newPatient)
    // adds the new patient in the next empty array location
    {
        int i = 0;
        while ((patients[i] != null) && (i < 10))
        {
            i=i+1;
        }
        if (i==10) { System.out.println("No more space in the waiting room."); }
        else { patients[i] = newPatient; }
    }

    public void callNextPatient()
    // finds the next patient, outputs their details
    // and removes the patient from the array
    {
        int index = 0;
        if (patients[0]==null)
        {
            System.out.println("The waiting room is empty.");
        }
        else
        {
            index = findNextPatientIndex();
            remove(index);
        }
    }

    private int findNextPatientIndex()
    // returns the index of the first patient with the
    // highest priority in the array patients
    {
        int max = 0;
    //... code missing ...
        return max;
    }

    private void remove(int n)
    // outputs the data of the patient instance at array index n
    // and removes that patient by shifting all remaining patients
    // by one index towards the front of the array
    {
    //... code missing ...
    }
}
