package november2015_healthclinic;

import java.util.LinkedList;

public class WaitingRoomDynamic
{
    private LinkedList<Patient> PatientList = new LinkedList<Patient>();
    // methods

    public void add(Patient P)
    // adds a patient at the end of the list
    {
        PatientList.addLast(P);
    }

    public void remove()
    // outputs the name of the next patient to see a doctor and
    // removes this patient instance from the list
    {
        int index = findNextPatientIndex();
        System.out.println(PatientList.get(index).getName());
        PatientList.remove(index);
    }

    private int findNextPatientIndex()
    {
        int i = 0, result = 0;
        Patient current, firstup;
        firstup = new Patient();
        firstup.setPriority(0);
        while (i < PatientList.size())
        {
            current = PatientList.get(i);
            if (current.getPriority() > firstup.getPriority())
            {
                firstup = current;
                result = i;
            }
            i=i+1;
        }
        return result;
    }
}
