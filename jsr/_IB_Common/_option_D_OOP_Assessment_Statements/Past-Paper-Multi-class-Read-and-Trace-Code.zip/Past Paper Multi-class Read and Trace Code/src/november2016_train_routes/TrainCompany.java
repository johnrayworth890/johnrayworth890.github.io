package november2016_train_routes;

public class TrainCompany
{
    private String companyName;
    private String companyCode;
    private int numberOfJourneys;
    private Journey[] journeyHistory = new Journey[100000];

    public TrainCompany(String x, String y)
    {
        this.companyName = x;
        this.companyCode = y;
        this.numberOfJourneys = 0;
    }
    public TrainCompany(){

    }

    public String getCompanyName() {
        return companyName;
    }

    public int getNumberOfJourneys() {
        return numberOfJourneys;
    }

    public String getCompanyCode() {
        return companyCode;
    }

    // accessor and mutator methods

    public Journey getJourney(int x)
    {
        return journeyHistory[x];
    }

    public void addJourney(Journey j)
    {
        journeyHistory[numberOfJourneys] = j;
        numberOfJourneys++;
    }

    public double averageDelay()
    {   //code missing
        return -999.9;//just to get rid of the return red squigglies
    }

    // returns the average delay for all of a company’s journeys
    public String longestDelay(Codes[] c)
    {   //code missing
        return "";//just to get rid of the return red squigglies
    }
    // returns the route name for the journey with the longest delay
    public String toString(Codes[] c)
    {   //code missing
        return "";
    }
}
