package november2016_train_routes;

public class Journey
{
    private String routeCode;
    // A unique identifier for a particular route
    private double delay;
    // Minutes late in arriving at the destination
    private boolean weatherRelated;
    // Equals true if the journey is affected by the weather,
    // otherwise false.
    // Constructor which initializes all 3 of the above data items
    // accessor and mutator methods.

    public Journey(String routeCode, double delay, boolean weatherRelated){
        this.routeCode = routeCode;
        this.delay = delay;
        this.weatherRelated = weatherRelated;
    }

    public double getDelay() {
        return delay;
    }

    public String getRouteCode() {
        return routeCode;
    }

    public boolean getWeatherRelated(){
        return weatherRelated;
    }
}
