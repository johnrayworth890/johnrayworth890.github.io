package mainstuff;

import java.util.Scanner;

import characterabilities.Tool;
import characterabilities.superpowers.*;
import characterabilities.weapons.*;
import characters.badguys.*;
import characters.goodguys.*;

public class GameGUI {

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {



        Object o = new Object();
        System.out.println(o.toString());

        PsychicSuperPower levitation = new PsychicSuperPower("Levitation", 70, false);
        //levitation.controlsMinds = true; //Not possible since attributes are private
        System.out.println(levitation.toString());


        Tool[] tools = new Tool[3];
        tools[0] = new MartialArtsWeapon("quarter star", 10, true);
        tools[1] = new PsychicSuperPower("telekinesis", 20, false);
        tools[2] = new MagicSuperPower("super nova", 101, true);

        JusticeLeague wonderWoman = new JusticeLeague("Wonder Woman", tools, 400, 8.6f);



        Tool[] thanosTools = new Tool[2];
        thanosTools[0] = new ContemporaryWeapon("Tazer", 35, "ACME Co.");
        thanosTools[1] = new PsychicSuperPower("Mind Reading", 25, true);

        BlackOrderBadGuy thanos = new BlackOrderBadGuy("Thanos", thanosTools, 123, true);


        boolean gameOn = true;
        while(gameOn){
            char whatToDo = 'z';
            System.out.println("Do you want to duel, (d), or tag team (t) or end the game? (e)");

            whatToDo = scanner.nextLine().toLowerCase().charAt(0);
            if(whatToDo == 'd'){
                System.out.println(duel(thanos, wonderWoman)); //<<<<<<<,---------- Add sout
            }
            else if(whatToDo == 't'){
                BadGuy [] badGuys = {thanos, thanos};
                GoodGuy [] goodGuys = {wonderWoman, wonderWoman};
                tagTeamFight(badGuys, goodGuys);
            }
            else if(whatToDo == 'e'){
                System.out.println("Thanks for playing.");
                gameOn = false;
            }
        }

        PsychicSuperPower superPower = new PsychicSuperPower();

    }

    public static String duel(BadGuy badGuy, GoodGuy goodGuy){

        double badGuyTotal = 0;
        for(int i = 0; i < badGuy.getTools().length; i++){
            badGuyTotal += badGuy.getTools()[i].calculateDamage();
        }

        double goodGuyTotal = 0;
        for(int i = 0; i < goodGuy.getTools().length; i++){
            goodGuyTotal += goodGuy.getTools()[i].calculateDamage();
        }


        String winner = "not set yet";
        if(badGuyTotal > goodGuyTotal){
            winner = badGuy.getPlayerName();
        }
        else if(goodGuyTotal > badGuyTotal){
            winner = goodGuy.getPlayerName();
        }
        else {
            winner = "tie";
        }
        return winner; //<<<<<<------------- Is this done yet?
    }

    public static String tagTeamFight(BadGuy [] villainTeam, GoodGuy [] heroesTeam){
        //To do later
        return "tie";
    }
}
