package characterabilities.weapons;

import characterabilities.Tool;

public abstract class Weapon extends Tool {

    private double damagePerHit = -999.99;

    public Weapon(){

    }

    public Weapon(String name, double damagePerHit){
        super(name);
        this.damagePerHit = damagePerHit;//
    }

    public double getDamagePerHit(){
        return damagePerHit;
    }



}
