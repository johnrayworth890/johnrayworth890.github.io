package characterabilities.weapons;

public class MartialArtsWeapon extends Weapon {

    private boolean isAncient = false;

    public MartialArtsWeapon(){

    }

    public MartialArtsWeapon(String toolName, double damagePerHit, boolean isAncient){
        super(toolName, damagePerHit);
        this.isAncient = isAncient;
    }

    public boolean isAncient() {
        return isAncient;
    }

    public double calculateDamage(){
        double damage = this.getDamagePerHit();
        if(isAncient){
            damage = this.getDamagePerHit() * 1.2;
        }
        return damage;
    }
}
