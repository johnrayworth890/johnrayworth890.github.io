package characterabilities.weapons;

public class ContemporaryWeapon extends Weapon {

    private String manufacturer = "not set yet";

    public ContemporaryWeapon(){

    }

    public ContemporaryWeapon(String toolName, double damagePerHit, String manufacturer){
        super(toolName, damagePerHit);
        this.manufacturer = manufacturer;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public double calculateDamage(){
        return this.getDamagePerHit();
    }
}
