package characterabilities;

public abstract class Tool extends Object{

    private String toolName;

    public Tool(){

    }

    public Tool(String toolName){
        this.toolName = toolName;
    }

    public String getToolName(){
        return toolName;
    }

    public abstract double calculateDamage();


}
