package characterabilities.superpowers;

public class PsychicSuperPower extends SuperPower {

    private boolean controlsMinds = false;
    private static int strength = 50;

    public PsychicSuperPower() {

    }

    public PsychicSuperPower(String toolName, int strengthTakenIn, boolean controlsMinds) {
        super(toolName, strengthTakenIn);
        this.controlsMinds = controlsMinds;
    }

    //First kind of polymorphism
    //Overloaded Constructors

    public PsychicSuperPower(String toolName, boolean controlsMinds) {
        super(toolName, strength); /// why not a variable for the strength?
        this.controlsMinds = controlsMinds;

    }

    public boolean isControlsMinds() {
        return controlsMinds;
    }

    public double calculateDamage() {
        double damage = this.getStrength();
        if (controlsMinds) {
            damage = this.getStrength() + 20;
        }
        return damage;
    }

    public String toString(){

        String stringToOutput = "";
        stringToOutput += "****************\n";
        stringToOutput += ("*Tool name: " + getToolName() + "\n");
        stringToOutput += ("*Strength (from 0 to 100): " + getStrength() + "\n");
        if(controlsMinds){
            stringToOutput += ("*It is mind controlling"+ "\n");
        }
        else{
            stringToOutput += ("*It is not mind controlling"+ "\n");
        }
        stringToOutput += "****************+\n";



        return stringToOutput;
    }


}
