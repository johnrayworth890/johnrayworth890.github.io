package characterabilities.superpowers;

import characterabilities.Tool;

public abstract class SuperPower extends Tool {

    private int strength = -999;

    public SuperPower(){

    }

    public SuperPower(String superPowerName, int strength){
        super(superPowerName);
        this.strength = strength;
    }

    public int getStrength(){
        return strength;
    }
}
