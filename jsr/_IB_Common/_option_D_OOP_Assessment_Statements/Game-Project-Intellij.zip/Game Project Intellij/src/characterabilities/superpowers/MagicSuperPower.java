package characterabilities.superpowers;

public class MagicSuperPower extends SuperPower {

     boolean isASpell;

     public MagicSuperPower(){

     }

     public MagicSuperPower(String toolName, int strength, boolean isASpell){
         super(toolName, strength);
         this.isASpell = isASpell;
     }

     public boolean getIsASpell(){
         return isASpell;
     }

    public double calculateDamage(){
        double damage = this.getStrength();
        if(isASpell){
            damage = this.getStrength() + 12;
        }
        return damage;
    }
}
