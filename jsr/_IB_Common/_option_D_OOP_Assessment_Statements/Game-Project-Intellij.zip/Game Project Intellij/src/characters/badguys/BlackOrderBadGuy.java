package characters.badguys;

import characterabilities.Tool;

public class BlackOrderBadGuy extends BadGuy{

    private boolean isAlive = false;

    public BlackOrderBadGuy(){

    }

    public BlackOrderBadGuy(String playerName, Tool[] tools, int numCitiesDestroyed, boolean isAlive){
        super(playerName, tools, numCitiesDestroyed);
        this.isAlive = isAlive;
    }

    public boolean getIsAlive(){
        return isAlive;
    }
}
