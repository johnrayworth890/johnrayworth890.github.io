package characters.badguys;

import characterabilities.Tool;
import characters.Player;

public abstract class BadGuy extends Player {

    private int numCitiesDestroyed = -999;

    public BadGuy(){

    }

    public BadGuy(String playerName, Tool[] tools, int numCitiesDestroyed){
        super(playerName, tools);
        this.numCitiesDestroyed = numCitiesDestroyed;

    }

    public int getNumCitiesDestroyed(){
        return numCitiesDestroyed;

    }
}
