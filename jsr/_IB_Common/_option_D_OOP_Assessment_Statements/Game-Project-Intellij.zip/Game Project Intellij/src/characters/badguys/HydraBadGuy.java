package characters.badguys;

import characterabilities.Tool;

public class HydraBadGuy extends BadGuy{

    private boolean captAmerFriend = false;

    public HydraBadGuy(){

    }

    public HydraBadGuy(String name, Tool [] tools, int numCitiesDestroyed, boolean captAmerFriend){
        super(name, tools, numCitiesDestroyed);
        this.captAmerFriend = captAmerFriend;
    }

    public boolean isCaptAmerFriend(){
        return captAmerFriend;
    }


}
