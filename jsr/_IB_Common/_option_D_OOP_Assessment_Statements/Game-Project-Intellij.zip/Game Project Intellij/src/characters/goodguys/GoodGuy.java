package characters.goodguys;
import characterabilities.Tool;
import characters.Player;

public abstract class GoodGuy extends Player {

    private int livesSaved = 0;

    public GoodGuy(){

    }

    public GoodGuy(String playerName, Tool [] tools, int livesSaved){
        super(playerName, tools);
        this.livesSaved = livesSaved;
    }
}
