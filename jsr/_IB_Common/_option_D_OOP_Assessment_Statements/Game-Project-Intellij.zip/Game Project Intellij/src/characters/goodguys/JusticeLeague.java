package characters.goodguys;

import characterabilities.Tool;

public class JusticeLeague extends GoodGuy {

    private float popularityIndex = -99.9f;

    public JusticeLeague(){

    }

    public JusticeLeague(String playerName, Tool[] tools, int numLivesSaved, float popularityIndex){
        super(playerName, tools, numLivesSaved);
        this.popularityIndex = popularityIndex;
    }

    public float getPopularityIndex(){
        return popularityIndex;
    }
}
