package characters.goodguys;

import characterabilities.Tool;

public class Avengers extends GoodGuy {

    private int shieldID = -999;

    public Avengers() {

    }

    public Avengers(String playerName, Tool[] tools, int livesSaved, int shieldID) {
        super(playerName, tools, livesSaved);
        this.shieldID = shieldID;
    }

    public int getShieldID() {
        return shieldID;
    }


}