package characters;

import characterabilities.*;

public abstract class Player{

    private String playerName = "not set yet";
    private Tool [] tools;

    //default constructor
    public Player(){

    }

    //overloaded constructor
    public Player(String playerName, Tool[] tools){
        this.playerName = playerName;
        this.tools = tools;
    }

    public String getPlayerName(){
        return playerName;
    }

    public Tool[] getTools(){
        return tools;
    }

}
